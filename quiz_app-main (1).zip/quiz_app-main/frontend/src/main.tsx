import React from "react";
import ReactDOM from "react-dom/client";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import App from "./App";
import ForgotPassword from "./components/pages/forgot-password/ForgotPassword";
import Login from "./components/pages/login-register/Login";
import NotFoundPage from "./components/pages/not-found/NotFoundPage";
import Profile from "./components/pages/profile/Profile";
import QuestionSet from "./components/pages/question-set/QuestionSet";
import Quiz from "./components/pages/quiz/Quiz";
import Score from "./components/pages/score/Score";
import "./index.css";
import Question from "./components/pages/question/Question";
import AddQuestion from "./components/pages/add-question/AddQuestion";
import FAQ from "./components/pages/faq/FAQ";
import About from "./components/pages/about/About";
import { AuthenticatedRoute } from "./components/AuthenticatedRoute";

const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    errorElement: <NotFoundPage />,
  },

  {
    path: "/login",
    element: <Login />,
  },
  {
    path: "/forgot",
    element: <ForgotPassword />,
  },
  {
    path: "/home",
    element: (
      <AuthenticatedRoute>
        <Question />
      </AuthenticatedRoute>
    ),
  },
  {
    path: "/quiz/:quizId",
    element: (
      <AuthenticatedRoute>
        <Quiz />
      </AuthenticatedRoute>
    ),
  },
  {
    path: "/profile",
    element: (
      <AuthenticatedRoute>
        <Profile />
      </AuthenticatedRoute>
    ),
  },
  {
    path: "/score",
    element: (
      <AuthenticatedRoute>
        <Score />
      </AuthenticatedRoute>
    ),
  },
  {
    path: "/questionset/:questionSetId",
    element: (
      <AuthenticatedRoute>
        <QuestionSet />
      </AuthenticatedRoute>
    ),
  },
  {
    path: "/add-question",
    element: (
      <AuthenticatedRoute>
        <AddQuestion />
      </AuthenticatedRoute>
    ),
  },
  {
    path: "/faq",
    element: (
      <AuthenticatedRoute>
        <FAQ />
      </AuthenticatedRoute>
    ),
  },
  {
    path: "/about",
    element: (
      <AuthenticatedRoute>
        <About />
      </AuthenticatedRoute>
    ),
  },
]);

ReactDOM.createRoot(document.getElementById("root") as HTMLElement).render(
  <RouterProvider router={router} />
);
