import React, { useState } from "react";

export interface GenericInterface {
  id: number | null;
  value: string;
}

interface DifficultyCategoryTableProps {
  title: string;
  genericData: GenericInterface[] | undefined;
  onSaveForEdit: (level: GenericInterface) => void;
  onSaveForAdd: (level: GenericInterface) => void;
  onDelete: (level: GenericInterface) => void;
}

function DifficultyCategoryTable({
  title,
  genericData,
  onDelete,
  onSaveForAdd,
  onSaveForEdit,
}: DifficultyCategoryTableProps) {
  const [editingLevel, setEditingLevel] = useState<GenericInterface | null>(
    null
  );
  const [newLevelValue, setNewLevelValue] = useState("");

  const handleEdit = (level: GenericInterface) => {
    setEditingLevel(level);
  };

  const handleAdd = () => {
    setEditingLevel({ id: null, value: "" });
  };

  const handleSave = async () => {
    //to avoid may be null error in onSaveForEdit
    if (editingLevel) {
      if (editingLevel?.id === null) {
        //we are saving new data
        console.log("add this new ", editingLevel);
        onSaveForAdd(editingLevel);
      } else {
        //we are saving edited data
        console.log("edit this ", editingLevel);
        onSaveForEdit(editingLevel);
      }
      // once save is clicked, show the table again
      setEditingLevel(null);
    }
  };
  const handleDelete = async (level: GenericInterface) => {
    console.log("delete this new ", level);
    onDelete(level);
  };

  return (
    <div className="difficulty-level-container">
      <h3>{title}</h3>
      <div className="difficulty-level-table">
        <table>
          <thead>
            <tr>
              <th>{title}</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {!editingLevel &&
              genericData?.map((level) => (
                <tr key={level.id}>
                  <td>{level.value}</td>
                  <td>
                    <button onClick={() => handleEdit(level)}>Edit</button>
                    <button onClick={() => handleDelete(level)}>Delete</button>
                  </td>
                </tr>
              ))}
            <tr>
              <td>
                {editingLevel && editingLevel.id === 0 ? (
                  <input
                    type="text"
                    value={editingLevel.value}
                    onChange={(e) =>
                      setEditingLevel({
                        ...editingLevel,
                        value: e.target.value,
                      })
                    }
                    required
                  />
                ) : (
                  editingLevel && (
                    <input
                      type="text"
                      value={editingLevel.value}
                      onChange={(e) =>
                        setEditingLevel({
                          ...editingLevel,
                          value: e.target.value,
                        })
                      }
                    />
                  )
                )}
              </td>
              <td>
                {editingLevel && (
                  <>
                    <button onClick={handleSave}>Save</button>
                    <button onClick={() => setEditingLevel(null)}>
                      Cancel
                    </button>
                  </>
                )}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
      {!editingLevel && (
        <button
          onClick={handleAdd}
          style={{ position: "sticky", top: "10px", zIndex: "999" }}
        >
          Add
        </button>
      )}
    </div>
  );
}

export default DifficultyCategoryTable;
