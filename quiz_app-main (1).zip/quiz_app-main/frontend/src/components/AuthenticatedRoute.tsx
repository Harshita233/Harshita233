import Login from "./pages/login-register/Login";

interface props {
  children: React.ReactElement;
}

export function AuthenticatedRoute({ children }: props) {
  const isAuthenticated = localStorage.getItem("access_token") != null;

  if (!isAuthenticated) {
    return <Login />;
  }
  return children;
}
