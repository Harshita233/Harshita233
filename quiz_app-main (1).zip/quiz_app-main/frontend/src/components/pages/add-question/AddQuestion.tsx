import React, { useEffect, useState } from "react";
import axiosInstance from "../../../axios";

import "./AddQuestion.scss";
import Navbar from "../../navbar/Navbar";
import CircularProgress from "../../progressbar/CircularProgress";
import { Category, DifficultyLevel } from "../question/Question";
import { useNavigate } from "react-router-dom";
import CustomToast from "../../toast/CustomToast";

interface QData {
  title: string;
  category_id: number;
  difficulty_level_id: number;
  data: Question[];
}

interface Question {
  question: string;
  hint: string;
  description: string;
  options: Option[];
}

interface Option {
  option: string;
  is_correct: boolean;
}

function AddQuestion() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState<boolean>(false);
  const [quizData, setQuizData] = useState<QData>({
    title: "",
    category_id: 0,
    difficulty_level_id: 0,
    data: [],
  });

  const [difficultyLevels, setDifficultyLevels] = useState<DifficultyLevel[]>();

  const [categories, setCategories] = useState<Category[]>();
  const [isToastVisible, setIsToastVisible] = useState(false);
  const [toastInfo, setToastInfo] = useState({
    message: "",
    status: "",
  });

  useEffect(() => {
    fetchCategories();
    fetchDifficultyLevels();
  }, []);

  const fetchCategories = async () => {
    setLoading(true);

    try {
      const response = await axiosInstance.get<Category[]>("/api/category/");
      setCategories(response.data);
    } catch (error) {
      console.error("Error fetching categories:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchDifficultyLevels = async () => {
    setLoading(true);

    try {
      const response = await axiosInstance.get<DifficultyLevel[]>(
        "/api/difficulty-level/"
      );
      setDifficultyLevels(response.data);
    } catch (error) {
      console.error("Error fetching difficulty levels:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleQuizTitleChange = (title: string) => {
    setQuizData((prevData) => ({ ...prevData, title }));
  };

  const handleCategoryChange = (categoryId: number) => {
    setQuizData((prevData) => ({ ...prevData, category_id: categoryId }));
  };

  const handleDifficultyLevelChange = (difficultyLevelId: number) => {
    setQuizData((prevData) => ({
      ...prevData,
      difficulty_level_id: difficultyLevelId,
    }));
  };

  const handleQuestionChange = (
    index: number,
    field: keyof Question,
    value: string
  ) => {
    setQuizData((prevData) => {
      const updatedData = [...prevData.data];
      updatedData[index] = {
        ...updatedData[index],
        [field]: value,
      };
      return { ...prevData, data: updatedData };
    });
  };

  const handleOptionChange = (
    questionIndex: number,
    optionIndex: number,
    value: string
  ) => {
    setQuizData((prevData) => {
      const updatedData = [...prevData.data];
      const updatedOptions = [...updatedData[questionIndex].options];
      updatedOptions[optionIndex] = {
        ...updatedOptions[optionIndex],
        option: value,
      };
      updatedData[questionIndex].options = updatedOptions;
      return { ...prevData, data: updatedData };
    });
  };

  const handleCorrectOptionChange = (
    questionIndex: number,
    optionIndex: number
  ) => {
    setQuizData((prevData) => {
      const updatedData = [...prevData.data];
      const updatedOptions = updatedData[questionIndex].options.map(
        (option, index) => ({
          ...option,
          is_correct: index === optionIndex,
        })
      );
      updatedData[questionIndex].options = updatedOptions;
      return { ...prevData, data: updatedData };
    });
  };

  const handleAddQuestion = () => {
    setQuizData((prevData) => ({
      ...prevData,
      data: [
        ...prevData.data,
        {
          question: "",
          hint: "",
          description: "",
          options: [
            { option: "", is_correct: false },
            { option: "", is_correct: false },
            { option: "", is_correct: false },
            { option: "", is_correct: false },
          ],
        },
      ],
    }));
  };

  const handleSave = async () => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      await axiosInstance.post(`/api/questions/`, quizData);
      navigate("/home");
    } catch (error) {
      setToastInfo({
        message: "Quiz add failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      navigate("/home");
      console.error("Error saving quiz data:", error);
    } finally {
      setLoading(false);
    }
  };

  const isSaveButtonDisabled = () => {
    const { title, category_id, difficulty_level_id, data } = quizData;
    if (
      !title ||
      category_id === 0 ||
      difficulty_level_id === 0 ||
      data.length === 0
    ) {
      return true;
    }

    for (const question of data) {
      if (!question.question || !question.description || !question.hint) {
        return true;
      }

      const hasOptionsFilled = question.options.every(
        (option) => option.option
      );
      if (!hasOptionsFilled) {
        return true;
      }
    }

    return false;
  };
  const handleRemoveQuestion = (index: number) => {
    setQuizData((prevData) => {
      const updatedData = [...prevData.data];
      updatedData.splice(index, 1);
      return { ...prevData, data: updatedData };
    });
  };
  return (
    <div className="add-question-page">
      <Navbar />
      {isToastVisible && <CustomToast info={toastInfo} />}
      {loading && <CircularProgress />}
      <div className="add-question-set-container">
        <div className="question-props">
          <h2>Add Question</h2>
          <label>Difficulty level</label>
          <select
            value={quizData.difficulty_level_id}
            onChange={(e) =>
              handleDifficultyLevelChange(Number(e.target.value))
            }
          >
            <option value={0}>Select Difficulty Level</option>
            {difficultyLevels?.map((level) => (
              <option key={level.id} value={level.id}>
                {level.difficulty_level}
              </option>
            ))}
          </select>

          <label>Category</label>
          <select
            value={quizData.category_id}
            onChange={(e) => handleCategoryChange(Number(e.target.value))}
          >
            <option value={0}>Select Category</option>
            {categories?.map((category) => (
              <option key={category.id} value={category.id}>
                {category.category}
              </option>
            ))}
          </select>

          <label>Title</label>
          <input
            type="text"
            value={quizData.title}
            onChange={(e) => handleQuizTitleChange(e.target.value)}
          />
        </div>

        <div className="question-cards">
          {quizData.data.map((data, index) => (
            <div className="question-card" key={index}>
              <div className="card-content">
                <h4>
                  Question {index + 1}
                  {/* Show the remove button only for the last card */}
                  {index === quizData.data.length - 1 && (
                    <div
                      className="remove-btn"
                      onClick={() => handleRemoveQuestion(index)}
                    >
                      &times;
                    </div>
                  )}
                </h4>
                <input
                  type="text"
                  value={data.question}
                  onChange={(e) =>
                    handleQuestionChange(index, "question", e.target.value)
                  }
                  placeholder="Enter question"
                />
                <div className="options">
                  {data.options.map((option, optionIndex) => (
                    <div key={optionIndex} className="option-edit">
                      <input
                        type="radio"
                        checked={option.is_correct}
                        onChange={() =>
                          handleCorrectOptionChange(index, optionIndex)
                        }
                      />
                      <input
                        type="text"
                        value={option.option}
                        onChange={(e) =>
                          handleOptionChange(index, optionIndex, e.target.value)
                        }
                        placeholder="Enter option"
                      />
                    </div>
                  ))}
                </div>
                <div className="explanation">
                  <label>Description</label>
                  <textarea
                    value={data.description}
                    onChange={(e) =>
                      handleQuestionChange(index, "description", e.target.value)
                    }
                    placeholder="Enter description"
                  />
                </div>
                <div className="explanation">
                  <label>Hint</label>
                  <input
                    type="text"
                    value={data.hint}
                    onChange={(e) =>
                      handleQuestionChange(index, "hint", e.target.value)
                    }
                    placeholder="Enter hint"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
        <div className="btn-group">
          <button onClick={handleAddQuestion}>Add Question</button>

          <button onClick={handleSave} disabled={isSaveButtonDisabled()}>
            Save
          </button>
        </div>
      </div>
    </div>
  );
}

export default AddQuestion;
