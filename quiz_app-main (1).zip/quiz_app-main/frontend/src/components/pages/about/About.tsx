import React, { useState } from "react";
import { Link } from "react-router-dom";
import axiosInstance from "../../../axios";
import Navbar from "../../navbar/Navbar";
import CircularProgress from "../../progressbar/CircularProgress";
import CustomToast from "../../toast/CustomToast";
import "./About.scss";

function About() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [message, setMessage] = useState("");
  const [loading, setLoading] = useState<boolean>(false);

  const [isToastVisible, setIsToastVisible] = useState(false);
  const [toastInfo, setToastInfo] = useState({
    message: "",
    status: "",
  });

  const handleSubmit = async (e: { preventDefault: () => void }) => {
    e.preventDefault();

    setLoading(true);
    setIsToastVisible(false);
    try {
      const response = await axiosInstance.post(
        `/auth/inquiry/`,
        {
          name: name,
          email: email,
          message: message,
        },
        { timeout: 60000 }
      );
      setToastInfo({
        message: "Feedback sent successfully!",
        status: "success",
      });
      setIsToastVisible(true);
    } catch (error) {
      console.error("Error processing inquiry form :", error);
      setToastInfo({
        message: "Error sending feedback!",
        status: "fail",
      });
      setIsToastVisible(true);
    } finally {
      setName("");
      setEmail("");
      setMessage("");
      setLoading(false);
    }
  };

  return (
    <div className="about-us-page">
      <Navbar></Navbar>
      <main>
        {isToastVisible && <CustomToast info={toastInfo} />}
        {loading && <CircularProgress />}
        <div className="container">
          <h1>About Us</h1>
          <div className="content">
            <p>
              Welcome to our private tutoring company, where education is our
              passion, and your success is our goal. We are a team of dedicated
              professionals committed to providing exceptional tutoring services
              tailored to your unique learning needs.
            </p>
            <p>
              Our company was founded on the belief that every student deserves
              personalized attention and guidance to unlock their full
              potential. With years of experience in the education field, our
              tutors are experts in their respective subjects and have a proven
              track record of helping students achieve academic excellence.
            </p>
            <p>
              What sets us apart is our commitment to creating a nurturing and
              supportive learning environment. We understand that every student
              learns differently, and our tutors are trained to adapt their
              teaching methods to suit individual learning styles. Whether you
              need assistance with math, science, language arts, or any other
              subject, our tutors will work closely with you to identify your
              strengths and areas for improvement, and develop a customized plan
              to help you reach your goals.
            </p>
            <p>
              In addition to our personalized tutoring services, we also offer
              an online quiz learning platform designed to help students
              reinforce their understanding and track their progress. Our
              interactive quizzes cover a wide range of subjects and grade
              levels, allowing students to practice and sharpen their skills at
              their own pace.
            </p>
            <br />
            <h3>Need help? Fill in the form below.</h3>
            <h4>
              Please fill out the form below and a member of our team will be in
              contact shortly.
            </h4>
            <div className="inquiry-form">
              <h2>Inquiry Form</h2>
              <form onSubmit={handleSubmit}>
                <div className="form-group">
                  <label htmlFor="name">Name:</label>
                  <input
                    type="text"
                    id="name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    required
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="email">Email:</label>
                  <input
                    type="email"
                    id="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    required
                  />
                </div>
                <div className="form-group">
                  <label htmlFor="message">Message:</label>
                  <textarea
                    id="message"
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    required
                  ></textarea>
                </div>
                <button type="submit">Submit</button>
              </form>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

export default About;
