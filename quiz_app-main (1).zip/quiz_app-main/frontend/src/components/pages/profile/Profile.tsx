import React, { useEffect, useState } from "react";
import Navbar from "../../navbar/Navbar";
import "./Profile.scss";
import axiosInstance from "../../../axios";
import CircularProgress from "../../progressbar/CircularProgress";
import CustomToast from "../../toast/CustomToast";

interface UserDetails {
  id: number;
  email: string;
  first_name: string;
  last_name: string;
  role: string;
  password?: string;
}

function Profile() {
  const [userDetails, setUserDetails] = useState<UserDetails | undefined>();
  const [loading, setLoading] = useState<boolean>(false);
  const [editing, setEditing] = useState(false);
  const [editedDetails, setEditedDetails] = useState<UserDetails | undefined>();
  const [isToastVisible, setIsToastVisible] = useState(false);
  const [toastInfo, setToastInfo] = useState({
    message: "",
    status: "",
  });

  useEffect(() => {
    fetchUserDetails();
  }, []);

  const fetchUserDetails = async () => {
    setLoading(true);
    try {
      const response = await axiosInstance.get<UserDetails>(
        "/auth/user-detail/"
      );
      setUserDetails(response.data);
      setEditedDetails(response.data);
    } catch (error) {
      console.error("Error fetching user details:", error);
    } finally {
      setLoading(false);
    }
  };

  const updateUserDetails = async () => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      const response = await axiosInstance.put<UserDetails>(
        "/auth/user-detail/",
        editedDetails
      );
      setUserDetails(response.data);
      setEditing(false);
      setToastInfo({
        message: "Profile updated!",
        status: "success",
      });
      setIsToastVisible(true);
    } catch (error) {
      setToastInfo({
        message: "Profile update failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error updating user details:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleEdit = () => {
    setEditing(true);
  };

  const handleCancel = () => {
    setEditedDetails(userDetails);
    setEditing(false);
  };

  const handleSave = () => {
    updateUserDetails();
  };

  const handleOnChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!editedDetails) return; // Check if editedDetails is defined
    setEditedDetails({ ...editedDetails, [e.target.name]: e.target.value });
  };

  return (
    <div className="profile-page">
      <Navbar></Navbar>
      {isToastVisible && <CustomToast info={toastInfo} />}
      {loading && <CircularProgress></CircularProgress>}

      <div className="profile-container">
        <div className="profile-form">
          <h1>Profile</h1>

          <div className="form-group">
            <label>First Name:</label>
            {editing ? (
              <input
                type="text"
                name="first_name"
                value={editedDetails?.first_name}
                onChange={(e) => handleOnChange(e)}
              />
            ) : (
              <span>{userDetails?.first_name}</span>
            )}
          </div>
          <div className="form-group">
            <label>Last Name:</label>
            {editing ? (
              <input
                type="text"
                name="last_name"
                value={editedDetails?.last_name}
                onChange={(e) => handleOnChange(e)}
              />
            ) : (
              <span>{userDetails?.last_name}</span>
            )}
          </div>
          <div className="form-group">
            <label>Email:</label>
            <span>{userDetails?.email}</span>
          </div>
          <div className="form-group">
            <label>Password:</label>
            {editing ? (
              <input
                type="password"
                name="password"
                value={editedDetails?.password}
                onChange={(e) => handleOnChange(e)}
              />
            ) : (
              <span>********</span>
            )}
          </div>

          {editing && (
            <button className="save-btn" onClick={handleSave}>
              Save Changes
            </button>
          )}
          {editing && (
            <button className="cancel-btn" onClick={handleCancel}>
              Cancel
            </button>
          )}
          {!editing && (
            <button className="edit-btn" onClick={handleEdit}>
              Edit
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

export default Profile;
