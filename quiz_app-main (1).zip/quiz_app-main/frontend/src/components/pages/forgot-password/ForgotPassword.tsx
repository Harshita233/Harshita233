import React, { useState } from "react";
import "./ForgotPassword.scss";
import { Link } from "react-router-dom";
import CircularProgress from "../../progressbar/CircularProgress";
import CustomToast from "../../toast/CustomToast";
import axiosInstance from "../../../axios";

function ForgotPassword() {
  const [email, setEmail] = useState("");
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [loading, setLoading] = useState<boolean>(false);
  const [isToastVisible, setIsToastVisible] = useState(false);
  const [toastInfo, setToastInfo] = useState({
    message: "",
    status: "",
  });

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    console.log("Email:", email);
    setLoading(true);
    setIsToastVisible(false);
    try {
      const response = await axiosInstance.post(`/auth/notify/`, {
        email: email,
      });
      setToastInfo({
        message: "Reset password success!",
        status: "success",
      });
      setIsToastVisible(true);
      setIsSubmitted(true);
    } catch (error) {
      setToastInfo({
        message: "Reset password failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error resetting password:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="forgot-password-page">
      {isToastVisible && <CustomToast info={toastInfo} />}
      {loading && <CircularProgress />}
      <div className="container">
        <h1>WELCOME TO QUIZ GAME</h1>
        <h2>Recover Password</h2>
        <form onSubmit={handleSubmit} className="forgot-password-form">
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>
          <button type="submit" className="submit-btn" disabled={isSubmitted}>
            Recover
          </button>
        </form>

        {isSubmitted && (
          <p>Recovery password will be sent to you email. Use it to login.</p>
        )}
        <div className="recover">
          <p>
            <Link to="/login">Login</Link>
          </p>
        </div>
      </div>
    </div>
  );
}

export default ForgotPassword;
