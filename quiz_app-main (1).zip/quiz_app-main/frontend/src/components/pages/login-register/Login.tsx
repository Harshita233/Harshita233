import React, { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import axiosInstance, { loginAxiosInstance } from "../../../axios";
import "./Login.scss";
import CircularProgress from "../../progressbar/CircularProgress";
import CustomToast from "../../toast/CustomToast";

function Login() {
  const navigate = useNavigate();
  const [loading, setLoading] = useState<boolean>(false);

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [isRegister, setIsRegister] = useState(false);
  const [isToastVisible, setIsToastVisible] = useState(false);
  const [toastInfo, setToastInfo] = useState({
    message: "",
    status: "",
  });

  const [isTeacher, setIsTeacher] = useState(false);

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();

    // Handle login and registration logic here
    if (isRegister) {
      console.log("executing register");
      setLoading(true);
      setIsToastVisible(false);
      try {
        const response = await loginAxiosInstance
          .post(`/auth/register/`, {
            email: email,
            first_name: firstName,
            last_name: lastName,
            password: password,
            role: isTeacher ? "teacher" : "student",
          })
          .then((res) => {
            console.log(res.data);
            setToastInfo({
              message: "Registration success!",
              status: "success",
            });
            setIsToastVisible(true);
            setIsRegister(false);
          });

        setFirstName("");
        setLastName("");
        setIsTeacher(false);
        setEmail("");
        setPassword("");
      } catch (error) {
        setToastInfo({
          message: "Registration failed. Try again!",
          status: "fail",
        });
        setIsToastVisible(true);
        console.error("Error logging in:", error);
      } finally {
        setLoading(false);
      }
    } else {
      console.log("executing login");
      setLoading(true);
      setIsToastVisible(false);
      try {
        const loginResponse = await loginAxiosInstance.post(`/auth/token/`, {
          email: email,
          password: password,
        });

        setToastInfo({
          message: "Login successful!",
          status: "success",
        });
        setIsToastVisible(true);

        localStorage.setItem("access_token", loginResponse.data.access);
        localStorage.setItem("refresh_token", loginResponse.data.refresh);

        axiosInstance.defaults.headers["Authorization"] =
          "Bearer " + localStorage.getItem("access_token");

        const userDetailResponse = await axiosInstance.get(
          `/auth/user-detail/`
        );

        localStorage.setItem("role", userDetailResponse.data.role);

        navigate("/home");
      } catch (error) {
        setToastInfo({
          message: "Incorrect email or password!",
          status: "fail",
        });
        setIsToastVisible(true);
        console.error("Error logging in:", error);
      } finally {
        setLoading(false);
      }
    }
  };

  function onRegisterClick() {
    setIsRegister(true);
  }
  function onLoginClick() {
    setIsRegister(false);
  }

  const showFirstNameField = (
    <div className="form-group">
      <label htmlFor="first-name">First Name</label>
      <input
        type="text"
        id="first-name"
        value={firstName}
        onChange={(e) => setFirstName(e.target.value)}
        required
      />
    </div>
  );

  const showLastNameField = (
    <div className="form-group">
      <label htmlFor="last-name">Last Name</label>
      <input
        type="text"
        id="last-name"
        value={lastName}
        onChange={(e) => setLastName(e.target.value)}
        required
      />
    </div>
  );

  const showForgotPassword = (
    <div className="forgot">
      <Link to="/forgot">Forgot password</Link>
    </div>
  );

  const showRegister = (
    <div className="register">
      <p>
        Don't have account?{" "}
        <a href="#" onClick={onRegisterClick}>
          Register
        </a>
      </p>
    </div>
  );

  const showLogin = (
    <div className="register">
      <p>
        <a href="#" onClick={onLoginClick}>
          Login
        </a>
      </p>
    </div>
  );

  const showLoginButton = (
    <button type="submit" className="submit-btn">
      Login
    </button>
  );

  const showRegisterButton = (
    <button type="submit" className="submit-btn">
      Register
    </button>
  );

  const showRoleBox = (
    <div className="checkbox-group">
      <input
        type="checkbox"
        checked={isTeacher}
        onChange={(e) => {
          setIsTeacher(e.target.checked);
        }}
      />
      <label>Register as a teacher</label>
    </div>
  );

  useEffect(() => {
    localStorage.removeItem("access_token");
    localStorage.removeItem("refresh_token");
    localStorage.removeItem("role");
  }, []);

  return (
    <div className="login-page">
      {isToastVisible && <CustomToast info={toastInfo} />}
      {loading && <CircularProgress />}
      <div className="container">
        <h1>WELCOME TO QUIZ GAME</h1>
        {isRegister ? <h2>Register</h2> : <h2>Login</h2>}
        <form onSubmit={handleSubmit} className="login-form">
          {isRegister && showFirstNameField}
          {isRegister && showLastNameField}
          <div className="form-group">
            <label htmlFor="email">Email</label>
            <input
              type="email"
              id="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              pattern="^([a-zA-Z0-9_\-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([a-zA-Z0-9\-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$"
              required
            />
          </div>
          <div className="form-group">
            <label htmlFor="password">Password</label>
            <input
              type="password"
              id="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>
          {isRegister && showRoleBox}
          {isRegister ? showRegisterButton : showLoginButton}
        </form>
        {!isRegister && showForgotPassword}
        {!isRegister ? showRegister : showLogin}
      </div>
    </div>
  );
}

export default Login;
