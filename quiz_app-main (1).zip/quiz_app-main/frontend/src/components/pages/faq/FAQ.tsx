import React, { useState } from "react";
import { Link } from "react-router-dom";
import Navbar from "../../navbar/Navbar";
import "./FAQ.scss";

function FAQ() {
  const [isTeacher, setIsTeacher] = useState(
    localStorage.getItem("role") !== "student" ? true : false
  );
  const teacherFAQ = (
    <div className="faq-list">
      <div className="faq-item">
        <h3>What is this quiz application?</h3>
        <p>
          This quiz application is a fun and interactive platform where you post
          quizzes and students will answer them.
        </p>
      </div>

      <div className="faq-item">
        <h3>How do I create a new category or difficulty level?</h3>
        <p>
          To add new category, on the home page, click on Add button on Category
          Section. Write category for which you want to create a quiz and click
          on save. Repeat the same process for difficulty level in difficulty
          level section .
        </p>
      </div>
      <div className="faq-item">
        <h3>How do add a new quiz ?</h3>
        <p>
          On the home page, click on Add button on Quiz section. There select
          the category, difficulty level and enter the quiz title. To add
          questions to this quiz, click add button at the bottom which will
          bring up a container to enter question, options, hint and description.
          Use the radio besides the option to mark the correct option. After
          adding desired number of question, click save.
        </p>
      </div>
      <div className="faq-item">
        <h3>What information do I need to provide when posting a new quiz?</h3>
        <p>
          When posting a new quiz, you'll need to provide the quiz title,
          category, difficulty level, time limit, and the actual questions with
          their respective options and correct answers. You can also include
          explanations or additional resources for each question.
        </p>
      </div>
      <div className="faq-item">
        <h3>Can I add hints for questions in a quiz?</h3>
        <p>
          Yes, you can add hints for each question in a quiz. These hints can
          provide additional guidance or clues to help students solve the
          question. However, it's important to note that students can only use
          up to 2 hints per quiz and no more than 1 hint per question.
        </p>
      </div>
      <div className="faq-item">
        <h3>Can I edit a quiz that has already been taken by students?</h3>
        <p>
          Yes, you can edit quizzes that have already been taken by students.
          However, any changes you make will only affect future attempts. Past
          student scores will remain unchanged to maintain the integrity of
          their previous attempts.
        </p>
      </div>
    </div>
  );

  const studentFAQ = (
    <div className="faq-list">
      <div className="faq-item">
        <h3>What is this quiz application?</h3>
        <p>
          This quiz application is a fun and interactive platform where you can
          test your knowledge across various topics and improve your knowledge.
        </p>
      </div>
      <div className="faq-item">
        <h3>How many categories and levels are covered in the quizzes?</h3>
        <p>
          Our online quiz platform offers a wide range of caetgories spanning
          various difficulty levels. We cover core subjects like math, science,
          english, and more.
        </p>
      </div>
      <div className="faq-item">
        <h3>How do I access the hints during a quiz?</h3>
        <p>
          During a quiz, you'll see a "Hint" button at the top right of each
          question. Clicking this button will reveal a hint to help you solve
          the question. However, remember that you can only use up to 3 hints
          per quiz and no more than one hint per question.
        </p>
      </div>
      <div className="faq-item">
        <h3>What happens if I run out of time during a quiz?</h3>
        <p>
          If you don't complete the quiz within the given timeframe, the quiz
          will automatically finish, and your score will be calculated based on
          the questions you answered. We recommend keeping an eye on the timer
          to ensure you have enough time to complete the quiz.
        </p>
      </div>
      <div className="faq-item">
        <h3>How are the scores calculated?</h3>
        <p>
          For each correct answer, you'll receive points. Your final score is
          the sum of all the points you've earned.
        </p>
      </div>
      <div className="faq-item">
        <h3>Can I review my previous quiz attempts?</h3>
        <p>
          Yes, our platform allows you to review your previous quiz attempts.
          You can view your scores, see the questions you answered correctly and
          incorrectly, and even revisit the explanations for each question. This
          feature is designed to help you learn from your mistakes and reinforce
          your understanding.
        </p>
      </div>
      <div className="faq-item">
        <h3>Can I delete a quiz I've already played?</h3>
        <p>
          Absolutely! Our platform allows you to delete quizzes you've already
          played. This feature encourages you to retake quizzes and improve your
          scores. By deleting a previously played quiz, you can start fresh and
          challenge yourself to achieve better results.
        </p>
      </div>
    </div>
  );

  return (
    <div className="faq-page">
      <Navbar></Navbar>
      <main>
        <div className="container">
          <h1>Frequently Asked Questions</h1>
          {isTeacher ? teacherFAQ : studentFAQ}
        </div>
      </main>
    </div>
  );
}

export default FAQ;
