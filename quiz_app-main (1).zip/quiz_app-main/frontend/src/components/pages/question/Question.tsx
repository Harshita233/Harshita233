import axiosInstance from "../../../axios";

import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "../../navbar/Navbar";
import "./Question.scss";
import CircularProgress from "../../progressbar/CircularProgress";
import DifficultyCategoryTable, {
  GenericInterface,
} from "../../difficulty-category-table/DifficultyCategoryTable";
import CustomToast from "../../toast/CustomToast";

interface Quiz {
  id: number;
  title: string;
  category: number;
  category_name: string;
  difficulty_level: number;
  difficulty_level_name: string;
}

export interface Category {
  id: number;
  category: string;
}

export interface DifficultyLevel {
  id: number;
  difficulty_level: string;
}

function Question() {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const navigate = useNavigate();
  const [isTeacher, setIsTeacher] = useState(false);

  const [difficultyLevels, setDifficultyLevels] =
    useState<GenericInterface[]>();

  const [category, setCategory] = useState<GenericInterface[]>();
  const [isToastVisible, setIsToastVisible] = useState(false);
  const [toastInfo, setToastInfo] = useState({
    message: "",
    status: "",
  });

  useEffect(() => {
    fetchCategories();
    fetchDifficultyLevels();
    fetchQuizzes();
  }, []);

  const fetchCategories = async () => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      const response = await axiosInstance.get<Category[]>("/api/category/");
      const transformedData: GenericInterface[] = response.data.map(
        (item: any) => ({
          id: item.id,
          value: item.category,
        })
      );
      console.log(transformedData);
      setCategory(transformedData);
    } catch (error) {
      setToastInfo({
        message: "Category failed to load!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error fetching categories:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchDifficultyLevels = async () => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      const response = await axiosInstance.get<DifficultyLevel[]>(
        "/api/difficulty-level/"
      );
      const transformedData: GenericInterface[] = response.data.map(
        (item: any) => ({
          id: item.id,
          value: item.difficulty_level,
        })
      );
      console.log(transformedData);

      setDifficultyLevels(transformedData);
    } catch (error) {
      setToastInfo({
        message: "Difficulty level to load!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error fetching difficulty levels:", error);
    } finally {
      setLoading(false);
    }
  };

  const fetchQuizzes = async () => {
    setLoading(true);
    setIsToastVisible(false);
    try {
      if (localStorage.getItem("role") !== "student") {
        setIsTeacher(true);
      }
      //editing localstorage may result in teacher buttons in UI
      //but is protected by token authorization in backend

      const response = await axiosInstance.get<Quiz[]>("/api/quiz");
      setQuizzes(response.data);
    } catch (error) {
      setToastInfo({
        message: "Quiz failed to load!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error fetching quizzes:", error);
    } finally {
      setLoading(false);
    }
  };
  const handleQuizPlay = (quizId: number) => {
    navigate(`/quiz/${quizId}`);
  };

  const handleQuizEdit = (quizId: number) => {
    navigate(`/questionset/${quizId}`);
  };
  const handleQuizDelete = async (quizId: number) => {
    setLoading(true);
    setIsToastVisible(false);
    try {
      await axiosInstance.delete(`/api/quiz/${quizId}/`).then((res) => {
        setQuizzes((prevQuizzes) =>
          prevQuizzes?.filter((quiz) => quiz.id !== quizId)
        );
        setToastInfo({
          message: "Quiz delete success!",
          status: "success",
        });
        setIsToastVisible(true);
      });
    } catch (error) {
      setToastInfo({
        message: "Quiz delete failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error deleting quiz:", error);
    } finally {
      setLoading(false);
    }
  };
  const handleAddQuiz = () => {
    navigate(`/add-question`);
  };

  const handleCategoryAdd = async (level: GenericInterface) => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      await axiosInstance
        .post(`/api/category/`, {
          category: level.value,
        })
        .then((res) => {
          setToastInfo({
            message: "Add success!",
            status: "success",
          });
          setIsToastVisible(true);
          const newCategory: GenericInterface = {
            id: res.data.id,
            value: res.data.category,
          };

          // Update the category state variable by adding the new category
          setCategory((prevCategories) =>
            prevCategories ? [...prevCategories, newCategory] : [newCategory]
          );
        });
    } catch (error) {
      setToastInfo({
        message: "Add failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error adding category:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCategoryEdit = async (level: GenericInterface) => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      await axiosInstance
        .put(`/api/category/${level.id}/`, {
          category: level.value,
        })
        .then((res) => {
          // Ensure that category is not undefined before updating
          if (category) {
            // Find the index of the edited category in the current category state
            const editedIndex = category.findIndex(
              (cat) => cat.id === level.id
            );

            if (editedIndex !== -1) {
              // Create a copy of the current category state
              const updatedCategories = [...category];

              // Update the category at the edited index with the new data
              updatedCategories[editedIndex] = {
                id: level.id,
                value: level.value,
              };

              // Update the category state variable with the updated categories
              setCategory(updatedCategories);
              setToastInfo({
                message: "Edit success!",
                status: "success",
              });
              setIsToastVisible(true);
            }
          }
        });
    } catch (error) {
      setToastInfo({
        message: "Edit failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error editing category:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleCategoryDelete = async (level: GenericInterface) => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      await axiosInstance.delete(`/api/category/${level.id}/`).then((res) => {
        setCategory((prevCategories) =>
          prevCategories?.filter((category) => category.id !== level.id)
        );
        setQuizzes((prevQuizzes) =>
          prevQuizzes?.filter((quiz) => quiz.category !== level.id)
        );
        setToastInfo({
          message: "Delete success!",
          status: "success",
        });
        setIsToastVisible(true);
      });
    } catch (error) {
      setToastInfo({
        message: "Delete failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error deleting category:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDifficultyLevelAdd = async (level: GenericInterface) => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      await axiosInstance
        .post(`/api/difficulty-level/`, {
          difficulty_level: level.value,
        })
        .then((res) => {
          const newDifficultyLevel: GenericInterface = {
            id: res.data.id,
            value: res.data.difficulty_level,
          };

          // Update the DifficultyLevels state variable by adding the new DifficultyLevel
          setDifficultyLevels((prevDifficultyLevels) =>
            prevDifficultyLevels
              ? [...prevDifficultyLevels, newDifficultyLevel]
              : [newDifficultyLevel]
          );
          setToastInfo({
            message: "Add success!",
            status: "success",
          });
          setIsToastVisible(true);
        });
    } catch (error) {
      setToastInfo({
        message: "Add failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error adding difficulty level:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDifficultyLevelEdit = async (level: GenericInterface) => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      await axiosInstance
        .put(`/api/difficulty-level/${level.id}/`, {
          //yeta forgot to make diff level for category body as copy pasted ani tanab
          difficulty_level: level.value,
        })
        .then((res) => {
          // Update the difficultyLevels state variable by editing the difficulty level

          // Ensure that difficultyLevels is not undefined before updating
          if (difficultyLevels) {
            // Find the index of the edited category in the current category state
            const editedIndex = difficultyLevels.findIndex(
              (diff) => diff.id === level.id
            );

            if (editedIndex !== -1) {
              // Create a copy of the current difficultyLevels state
              const updatedDifficultyLevels = [...difficultyLevels];

              // Update the category at the edited index with the new data
              updatedDifficultyLevels[editedIndex] = {
                id: level.id,
                value: level.value,
              };

              // Update the category state variable with the updated categories
              setDifficultyLevels(updatedDifficultyLevels);
              setToastInfo({
                message: "Edit success!",
                status: "success",
              });
              setIsToastVisible(true);
            }
          }
        });
    } catch (error) {
      setToastInfo({
        message: "Edit failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error editing difficulty level:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDifficultyLevelDelete = async (level: GenericInterface) => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      await axiosInstance
        .delete(`/api/difficulty-level/${level.id}/`)
        .then((res) => {
          setDifficultyLevels((prevDifficultyLevels) =>
            prevDifficultyLevels?.filter(
              (prevDifficultyLevels) => prevDifficultyLevels.id !== level.id
            )
          );
          setQuizzes((prevQuizzes) =>
            prevQuizzes?.filter((quiz) => quiz.difficulty_level !== level.id)
          );
          setToastInfo({
            message: "Delete success!",
            status: "success",
          });
          setIsToastVisible(true);
        });
    } catch (error) {
      setToastInfo({
        message: "Deleete failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error deleting difficulty level:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="question-page">
      <Navbar></Navbar>
      <main>
        {isToastVisible && <CustomToast info={toastInfo} />}
        {loading && <CircularProgress />}
        {isTeacher && (
          <div className="table-container">
            <DifficultyCategoryTable
              title="Category"
              genericData={category}
              onSaveForAdd={handleCategoryAdd}
              onSaveForEdit={handleCategoryEdit}
              onDelete={handleCategoryDelete}
            />
            <DifficultyCategoryTable
              title="Difficulty Level"
              genericData={difficultyLevels}
              onSaveForAdd={handleDifficultyLevelAdd}
              onSaveForEdit={handleDifficultyLevelEdit}
              onDelete={handleDifficultyLevelDelete}
            />
          </div>
        )}
        <div className="quiz-section">
          <h2>Quizzes</h2>
          <div className="quiz-table-container">
            <table>
              <thead>
                <tr>
                  <th>SN</th>
                  <th>Title</th>
                  <th>Category</th>
                  <th>Difficulty Level</th>
                  <th>Action</th>
                </tr>
              </thead>
              <tbody>
                {quizzes.map((quiz, index) => (
                  <tr key={quiz.id}>
                    <td>{index + 1}</td>
                    <td>{quiz.title}</td>
                    <td>{quiz.category_name}</td>
                    <td>{quiz.difficulty_level_name}</td>
                    <td>
                      {!isTeacher && (
                        <button
                          className="btn"
                          onClick={() => handleQuizPlay(quiz.id)}
                        >
                          Play
                        </button>
                      )}
                      {isTeacher && (
                        <button onClick={() => handleQuizEdit(quiz.id)}>
                          Edit
                        </button>
                      )}
                      {isTeacher && (
                        <button onClick={() => handleQuizDelete(quiz.id)}>
                          Delete
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {isTeacher && <button onClick={() => handleAddQuiz()}>Add</button>}
        </div>
      </main>
    </div>
  );
}
export default Question;
