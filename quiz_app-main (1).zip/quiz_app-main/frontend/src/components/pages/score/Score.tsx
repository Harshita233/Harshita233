import React, { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import Navbar from "../../navbar/Navbar";
import "./Score.scss";
import axiosInstance from "../../../axios";
import CircularProgress from "../../progressbar/CircularProgress";
import CustomToast from "../../toast/CustomToast";

interface ScoreData {
  questionset_id: number;
  quiz_id: number;
  title: string;
  category_id: number;
  category: string;
  difficulty_level_id: number;
  difficulty_level: string;
  played_date: string;
  first_name: string;
  score: number;
}

function Score() {
  const navigate = useNavigate();

  const [scoreData, setScoreData] = useState<ScoreData[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [isToastVisible, setIsToastVisible] = useState(false);
  const [toastInfo, setToastInfo] = useState({
    message: "",
    status: "",
  });

  useEffect(() => {
    fetchQuizHistory();
  }, []);

  const fetchQuizHistory = async () => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      const response = await axiosInstance.get<ScoreData[]>(
        "/api/quiz-history/"
      );
      setScoreData(response.data);
    } catch (error) {
      setToastInfo({
        message: "Score retrival failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error fetching quiz history:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleDelete = async (questionSetId: number) => {
    setLoading(true);
    setIsToastVisible(false);

    try {
      await axiosInstance
        .delete(`/api/quiz-history/${questionSetId}`)
        .then((res) => {
          const updatedScoreData = scoreData.filter(
            (data) => data.questionset_id !== questionSetId
          );
          setScoreData(updatedScoreData);
          console.log(`Deleted question_set_id: ${questionSetId}`);
        });
    } catch (error) {
      setToastInfo({
        message: "Delete failed!",
        status: "fail",
      });
      setIsToastVisible(true);
      console.error("Error deleting question set:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleView = (questionSetId: number) => {
    navigate(`/questionset/${questionSetId}`);
  };

  return (
    <div className="score-page">
      <Navbar></Navbar>
      <main>
        <div className="score-section">
          <h1>Score</h1>
          {isToastVisible && <CustomToast info={toastInfo} />}
          {loading && <CircularProgress></CircularProgress>}

          <div className="my-score-container">
            <table>
              <thead>
                <tr>
                  <th>SN</th>
                  <th>Title</th>
                  <th>Category</th>
                  <th>Difficulty Level</th>
                  <th>Played Date</th>
                  <th>Score</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {scoreData.map((data) => (
                  <tr key={data.questionset_id}>
                    <td>{data.questionset_id}</td>
                    <td>{data.title}</td>
                    <td>{data.category}</td>
                    <td>{data.difficulty_level}</td>

                    <td>{data.played_date}</td>
                    <td>{data.score}</td>
                    <td>
                      <button
                        className="view-btn"
                        onClick={() => handleView(data.questionset_id)}
                      >
                        View
                      </button>
                      <button
                        className="delete-btn"
                        onClick={() => handleDelete(data.questionset_id)}
                      >
                        Delete
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>
    </div>
  );
}

export default Score;
