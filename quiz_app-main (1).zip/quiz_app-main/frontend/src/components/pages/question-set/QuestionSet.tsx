import React, { useEffect, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import Navbar from "../../navbar/Navbar";
import axiosInstance from "../../../axios";
import CircularProgress from "../../progressbar/CircularProgress";
import "./QuestionSet.scss";
import CustomToast from "../../toast/CustomToast";

interface QData {
  quiz_id?: number;
  title?: string;
  category?: string;
  category_id?: number;
  difficulty_level: string;
  difficulty_level_id: number;
  score: number;
  data: Question[];
}

interface Question {
  id: number;
  question: string;
  hint: string;
  description: string;
  selected_option_id?: number | null;
  quiz_id?: number;
  options: Option[];
}

interface Option {
  id: number;
  option: string;
  is_correct: boolean;
  question_id: number;
}

function QuestionSet() {
  const { questionSetId } = useParams();
  console.log("asdasdasd" + questionSetId);
  const [editMode, setEditMode] = useState(false);
  const [editQuestionId, setEditQuestionId] = useState<number | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [isTeacher, setIsTeacher] = useState(
    localStorage.getItem("role") !== "student" ? true : false
  );
  const [qData, setQData] = useState<QData>();
  const [editedData, setEditedData] = useState<any>(null);
  const [isToastVisible, setIsToastVisible] = useState(false);
  const [toastInfo, setToastInfo] = useState({
    message: "",
    status: "",
  });

  useEffect(() => {
    fetchScores();
  }, []);

  const fetchScores = async () => {
    setLoading(true);
    try {
      let url = `/api/quiz-history/`;
      if (localStorage.getItem("role") !== "student") {
        url = `/api/questions/`;
      }
      const response = await axiosInstance.get(`${url}${questionSetId}/`);
      console.log(response.data);

      setQData(response.data);
    } catch (error) {
      console.error("Error fetching questions:", error);
    } finally {
      setLoading(false);
    }
  };

  const handleEditMode = (questionId: number) => {
    setEditQuestionId(questionId);
  };

  const handleCancelEdit = (questionId: number) => {
    setEditQuestionId(null);
  };

  const handleSaveEdit = async (questionId: number) => {
    setLoading(true);
    setIsToastVisible(false);

    // Perform any necessary actions to save the edited data
    const editedQuestion = qData?.data.find((q) => q.id === questionId);

    if (editedQuestion) {
      const editedOptions = editedQuestion.options.map((option) => ({
        id: option.id,
        option: option.option,
        is_correct: option.is_correct,
        question_id: option.question_id,
      }));

      const editedJsonData = {
        question_id: editedQuestion.id,
        question: editedQuestion.question,
        hint: editedQuestion.hint,
        description: editedQuestion.description,
        quiz_id: editedQuestion.quiz_id,
        options: editedOptions,
      };

      try {
        const response = await axiosInstance.put(
          `/api/question/${questionId}/`,
          editedJsonData
        );
        setToastInfo({
          message: "Edit successful!",
          status: "success",
        });
        setIsToastVisible(true);
      } catch (error) {
        setToastInfo({
          message: "Update failed!",
          status: "fail",
        });
        setIsToastVisible(true);
        console.error("Error updating question: ", error);
      } finally {
        setLoading(false);
      }

      setEditedData(editedJsonData);
      console.log(editedJsonData);
    }

    setEditQuestionId(null);
  };

  const handleQuestionChange = (
    questionId: number,
    value: string,
    field: "question" | "description" | "hint"
  ) => {
    if (qData) {
      const updatedData = qData.data.map((q) => {
        if (q.id === questionId) {
          return {
            ...q,
            [field]: value,
          };
        }
        return q;
      });
      setQData({ ...qData, data: updatedData });
    }
  };

  const handleOptionChange = (
    questionId: number,
    optionId: number,
    value: string
  ) => {
    if (qData) {
      const updatedData = qData?.data.map((q) => {
        if (q.id === questionId) {
          const updatedOptions = q.options.map((option) => {
            if (option.id === optionId) {
              return {
                ...option,
                option: value,
              };
            }
            return option;
          });
          return {
            ...q,
            options: updatedOptions,
          };
        }
        return q;
      });
      setQData({ ...qData, data: updatedData });
    }
  };

  const handleCorrectOptionChange = (questionId: number, optionId: number) => {
    if (qData) {
      const updatedData = qData?.data.map((q) => {
        if (q.id === questionId) {
          const updatedOptions = q.options.map((option) => {
            if (option.id === optionId) {
              return {
                ...option,
                is_correct: true,
              };
            } else {
              return {
                ...option,
                is_correct: false,
              };
            }
          });
          return {
            ...q,
            options: updatedOptions,
          };
        }
        return q;
      });
      setQData({ ...qData, data: updatedData });
    }
  };

  return (
    <div className="questionset-page">
      <Navbar></Navbar>
      {isToastVisible && <CustomToast info={toastInfo} />}
      {loading && <CircularProgress />}
      <div className="view-question-set-container">
        {/* <h1>View Question Set</h1> */}
        <div className="question-cards">
          {qData?.data.map((data, index) => (
            <div className="question-card" key={index}>
              <div className="card-content">
                {editQuestionId === data.id ? (
                  // Edit mode
                  <>
                    <h4>Question</h4>
                    <input
                      type="text"
                      value={data.question}
                      onChange={(e) =>
                        handleQuestionChange(
                          data.id,
                          e.target.value,
                          "question"
                        )
                      }
                    />
                    <div className="options">
                      {data.options.map((option) => (
                        <div key={option.id} className="option-edit">
                          <input
                            type="radio"
                            checked={option.is_correct}
                            onChange={() =>
                              handleCorrectOptionChange(data.id, option.id)
                            }
                          />
                          <input
                            type="text"
                            value={option.option}
                            onChange={(e) =>
                              handleOptionChange(
                                data.id,
                                option.id,
                                e.target.value
                              )
                            }
                          />
                        </div>
                      ))}
                    </div>
                    <div className="explanation">
                      <label>Description</label>
                      <textarea
                        value={data.description}
                        onChange={(e) =>
                          handleQuestionChange(
                            data.id,
                            e.target.value,
                            "description"
                          )
                        }
                      />
                    </div>
                    <div className="explanation">
                      <label>Hint</label>
                      <input
                        type="text"
                        value={data.hint}
                        onChange={(e) =>
                          handleQuestionChange(data.id, e.target.value, "hint")
                        }
                      />
                    </div>
                    <div className="card-actions">
                      <button onClick={() => handleCancelEdit(data.id)}>
                        Cancel
                      </button>
                      <button onClick={() => handleSaveEdit(data.id)}>
                        Save
                      </button>
                    </div>
                  </>
                ) : (
                  // Read-only view
                  <>
                    <h3>{data.question}</h3>
                    <div className="options">
                      {data.options.map((option) => (
                        <div
                          className={`option ${
                            option.is_correct
                              ? "correct"
                              : data.selected_option_id !== null &&
                                data.selected_option_id === option.id
                              ? "incorrect"
                              : data.selected_option_id === null
                              ? "incorrect"
                              : ""
                          }`}
                          key={option.id}
                        >
                          {option.option}
                        </div>
                      ))}
                    </div>
                    <div className="explanation">
                      <label>Explanation:</label>
                      <textarea value={data.description} readOnly />
                    </div>
                    {isTeacher && (
                      <div className="explanation">
                        <label>Hint:</label>
                        <input type="text" value={data.hint} readOnly />
                      </div>
                    )}

                    {isTeacher && (
                      <div className="card-actions">
                        <button onClick={() => handleEditMode(data.id)}>
                          Edit
                        </button>
                      </div>
                    )}
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default QuestionSet;
