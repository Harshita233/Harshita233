import React, { useEffect, useState } from "react";
import "./CustomToast.scss";

interface Props {
  info: { message: string; status: string };
}

function CustomToast({ info }: Props) {
  const [showToast, setShowToast] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => {
      setShowToast(false);
    }, 3000);

    return () => clearTimeout(timer);
  }, []);

  return (
    <div
      className={`toast-container ${showToast ? "toast-show" : ""} ${
        info.status
      }`}
    >
      <div className="toast-content">{info.message}</div>
    </div>
  );
}

export default CustomToast;
