import React from "react";
import "./CircularProgress.scss";

function CircularProgress() {
  return (
    <div className="progress-overlay">
      <div className="circular-progress"></div>
    </div>
  );
}

export default CircularProgress;
