from django.urls import path
from .views import QuestionAPIView, QuestionCreateAPIView, QuestionDetailAPIView, QuestionUpdateAPIView, QuizApiView, QuizHistoryAPIView, CategoryApiView, ScoreAPIView, DifficultyLevelApiView

urlpatterns = [
    # GET POST AND DELETE Category
    path('category/', CategoryApiView.as_view(), name='category-list'),
    path('category/<int:pk>/', CategoryApiView.as_view(), name='category-detail'),

    # GET POST AND DELETE Difficulty level
    path('difficulty-level/', DifficultyLevelApiView.as_view(), name='difficulty-level-list'),
    path('difficulty-level/<int:pk>/', DifficultyLevelApiView.as_view(), name='difficulty-level-detail'),

    # GET AND DELETE Quiz 
    path('quiz/', QuizApiView.as_view(), name='quiz-list'),
    path('quiz/<int:pk>/', QuizApiView.as_view(), name='quiz-delete'),

    #GET, DELETE quiz question  
    path('questions/<int:quiz_id>/', QuestionAPIView.as_view(), name='question-api'),
    #POST Endpoint for creating questions, quiz, and options 
    path('questions/', QuestionCreateAPIView.as_view(), name='create_question'),
    #PUT update question by teacher  
    path('question/<int:question_id>/', QuestionUpdateAPIView.as_view(), name='question-update'),

    #Calculate score
    path('score/', ScoreAPIView.as_view(), name='score'),
    #List quizzes taken  
    path('quiz-history/', QuizHistoryAPIView.as_view(), name='quiz-history'),
    #GET DELETE detailed quiz history
    path('quiz-history/<int:questionset_id>/', QuestionDetailAPIView.as_view(), name='question-detail'),
    ]