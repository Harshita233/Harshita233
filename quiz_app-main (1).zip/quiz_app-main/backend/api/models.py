# This is an auto-generated Django model module.
# You'll have to do the following manually to clean this up:
#   * Rearrange models' order
#   * Make sure each model has one field with primary_key=True
#   * Make sure each ForeignKey and OneToOneField has `on_delete` set to the desired behavior
#   * Remove `managed = False` lines if you wish to allow Django to create, modify, and delete the table
# Feel free to rename the models, but don't rename db_table values or field names.
from django.db import models

from members.models import UserAccount



class Category(models.Model):
    # category name should be unique
    category = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.category
    
class DifficultyLevel(models.Model):
    difficulty_level = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return self.difficulty_level
    
class Quiz(models.Model):
    title = models.TextField(max_length=100)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    difficulty_level = models.ForeignKey(DifficultyLevel, on_delete=models.CASCADE)

    def __str__(self):
        return self.title
    
class Question(models.Model):
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE)
    question = models.TextField(max_length=200)
    hint = models.TextField(max_length=100)
    description = models.TextField(max_length=200)

    def __str__(self):
        return self.question
    
class Option(models.Model):
    option = models.TextField(max_length=100)
    is_correct = models.BooleanField(default=False)
    question = models.ForeignKey(
        Question, on_delete=models.CASCADE, related_name='options')

    def __str__(self):
        return self.option

class QuestionSet(models.Model):
    quiz = models.ForeignKey(Quiz, on_delete=models.CASCADE)
    user = models.ForeignKey(UserAccount, on_delete=models.CASCADE)
    played_date = models.DateTimeField()
    score = models.IntegerField()
    def __str__(self):
        return self.quiz.title
    
class QuestionSetDetails(models.Model):
    question_set = models.ForeignKey(QuestionSet, on_delete=models.CASCADE)
    question = models.ForeignKey(Question, on_delete=models.CASCADE)
    option =  models.IntegerField()
    def __str__(self):
        return self.question.question