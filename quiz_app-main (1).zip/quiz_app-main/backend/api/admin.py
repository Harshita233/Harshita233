from django.contrib import admin

# Register your models here.
from .models import Category
from .models import DifficultyLevel
from .models import Quiz
from .models import Question
from .models import Option
from .models import QuestionSet
from .models import QuestionSetDetails

admin.site.register(Category)
admin.site.register(DifficultyLevel)
admin.site.register(Quiz)
admin.site.register(Question)
admin.site.register(Option)
admin.site.register(QuestionSet)
admin.site.register(QuestionSetDetails)