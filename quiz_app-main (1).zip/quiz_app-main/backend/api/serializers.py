from rest_framework import serializers
from .models import Category, DifficultyLevel, Quiz, Option, Question, QuestionSet, QuestionSetDetails

class CategorySerializer(serializers.ModelSerializer):

    class Meta:
        model = Category
        fields = "__all__"

class DifficultyLevelSerializer(serializers.ModelSerializer):

    class Meta:
        model = DifficultyLevel
        fields = "__all__"

class QuizSerializer(serializers.ModelSerializer):
    category_name = serializers.CharField(source='category.category',read_only=True)
    difficulty_level_name = serializers.CharField(source='difficulty_level.difficulty_level',read_only=True)
 
    class Meta:
        model = Quiz
        fields = "__all__"
        fields = ['id', 'title', 'category', 'category_name', 'difficulty_level', 'difficulty_level_name']


class OptionSerializer(serializers.ModelSerializer):

    class Meta:
        model = Option
        fields = "__all__"

class QuestionSerializer(serializers.ModelSerializer):

    class Meta:
        model = Question
        fields = "__all__"

class QuestionSetSerializer(serializers.ModelSerializer):

    class Meta:
        model = QuestionSet
        fields = "__all__"

class QuestionSetDetailsSerializer(serializers.ModelSerializer):

    class Meta:
        model = QuestionSetDetails
        fields = "__all__"

class QuizHistorySerializer(serializers.Serializer):
    questionset_id = serializers.IntegerField()
    quiz_id = serializers.IntegerField()
    title = serializers.CharField()
    category_id = serializers.IntegerField()
    category = serializers.CharField()
    difficulty_level_id = serializers.IntegerField()
    difficulty_level = serializers.CharField()
    played_date = serializers.DateField()
    first_name= serializers.CharField()
    score = serializers.IntegerField()
