from rest_framework.exceptions import MethodNotAllowed
from django.shortcuts import render
from rest_framework.viewsets import ModelViewSet
from rest_framework.views import APIView
from .serializers import CategorySerializer, DifficultyLevelSerializer, QuizSerializer, QuestionSerializer, QuestionSetSerializer, QuestionSetDetailsSerializer, OptionSerializer,QuizHistorySerializer
from .models import Category, DifficultyLevel, Quiz, Question, QuestionSet, QuestionSetDetails, Option
from rest_framework.response import Response
from rest_framework import status
from members.permissions import IsTeacher
from django.utils import timezone
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.permissions import IsAdminUser, IsAuthenticated
from members.models import UserAccount

class CategoryApiView(APIView):
    permission_classes = [IsAuthenticated] 
    serializer_class = CategorySerializer

    def get(self, request):
        categories = Category.objects.all()
        serializer = CategorySerializer(categories, many=True)
        return Response(serializer.data)

    def post(self, request):
        
        if not request.user.role==UserAccount.ROLE_CHOICES[1][0]:
            return Response({'detail': 'You do not have permission to perform this action'}, status=status.HTTP_403_FORBIDDEN)

        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        if not request.user.role==UserAccount.ROLE_CHOICES[1][0]:
            return Response({'detail': 'You do not have permission to perform this action'}, status=status.HTTP_403_FORBIDDEN)

        category = Category.objects.get(pk=pk)
        serializer = CategorySerializer(category, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        if not request.user.role==UserAccount.ROLE_CHOICES[1][0]:
            return Response({'detail': 'You do not have permission to perform this action'}, status=status.HTTP_403_FORBIDDEN)
 
        category = Category.objects.get(pk=pk)
        category.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)


class DifficultyLevelApiView(APIView):
    permission_classes = [IsAuthenticated] 
    serializer_class = DifficultyLevelSerializer

    def get(self, request):
        difficulty_levels = DifficultyLevel.objects.all()
        serializer = DifficultyLevelSerializer(difficulty_levels, many=True)
        return Response(serializer.data)

    def post(self, request):
        if not request.user.role==UserAccount.ROLE_CHOICES[1][0]:
            return Response({'detail': 'You do not have permission to perform this action'}, status=status.HTTP_403_FORBIDDEN)

        serializer = self.serializer_class(data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def put(self, request, pk):
        if not request.user.role==UserAccount.ROLE_CHOICES[1][0]:
            return Response({'detail': 'You do not have permission to perform this action'}, status=status.HTTP_403_FORBIDDEN)

        difficulty_level = DifficultyLevel.objects.get(pk=pk)
        serializer = DifficultyLevelSerializer(difficulty_level, data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

    def delete(self, request, pk):
        if not request.user.role==UserAccount.ROLE_CHOICES[1][0]:
            return Response({'detail': 'You do not have permission to perform this action'}, status=status.HTTP_403_FORBIDDEN)
 
        difficulty_level = DifficultyLevel.objects.get(pk=pk)
        difficulty_level.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class QuizApiView(APIView):

    permission_classes = [IsAuthenticated]
    serializer_class = QuizSerializer

    def get(self, request):
        quizzes = Quiz.objects.all()
        serializer = self.serializer_class(quizzes, many=True)
        return Response(serializer.data)

    def delete(self, request, pk):
        if not request.user.role==UserAccount.ROLE_CHOICES[1][0]:
            return Response({'detail': 'You do not have permission to perform this action'}, status=status.HTTP_403_FORBIDDEN)

        try:
            quiz = Quiz.objects.get(pk=pk)
        except Quiz.DoesNotExist:
            return Response({'error': 'Quiz not found'}, status=status.HTTP_404_NOT_FOUND)

        quiz.delete()
        return Response(status=status.HTTP_204_NO_CONTENT)

class QuestionAPIView(APIView):

    permission_classes = [IsAuthenticated]

    def get(self, request, quiz_id):
        try:
            # Retrieve the quiz model
            quiz = Quiz.objects.get(pk=quiz_id)
            
            # Get category and difficulty level names
            category_name = quiz.category.category
            difficulty_level_name = quiz.difficulty_level.difficulty_level
            
            # Get all questions for the quiz
            questions = Question.objects.filter(quiz=quiz_id)
            
            # Serialize questions and options
            question_serializer = QuestionSerializer(questions, many=True)
            data = question_serializer.data
            
            # Add options to each question
            for question_data in data:
                question_id = question_data['id']
                options = Option.objects.filter(question=question_id)
                option_serializer = OptionSerializer(options, many=True)
                question_data['options'] = option_serializer.data
            
            # Prepare the response data
            response_data = {
                'id': quiz.id,
                'title': quiz.title,
                'category': category_name,
                'category_id': quiz.category.id,
                'difficulty_level': difficulty_level_name,
                'difficulty_level_id': quiz.difficulty_level.id,
                'data': data
            }
            
            return Response(response_data)
        
        except Quiz.DoesNotExist:
            return Response({'error': 'Quiz not found'}, status=404)
    
    def delete(self, request, quiz_id):

        if not request.user.role==UserAccount.ROLE_CHOICES[1][0]:
            return Response({'detail': 'You do not have permission to perform this action'}, status=status.HTTP_403_FORBIDDEN)

        try:
            quiz = Quiz.objects.get(pk=quiz_id)
        except Quiz.DoesNotExist:
            return Response({'error': 'Quiz not found'}, status=404)

        # Now delete the quiz itself
        quiz.delete()
        return Response({'message': 'Quiz deleted successfully'}, status=204)    

        
class QuestionCreateAPIView(APIView):

    permission_classes = [IsTeacher]

    def post(self, request):

            # Get the data from the request body
            data = request.data

            # Create a new Quiz object
            quiz_data = {
                'title': data.get('title'),
                'category': data.get('category_id'),
                'difficulty_level': data.get('difficulty_level_id')
            }
            quiz_serializer = QuizSerializer(data=quiz_data)
            if quiz_serializer.is_valid():
                quiz = quiz_serializer.save()
            else:
                return Response(quiz_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            # Create Question and Option objects for each question in the data
            questions_data = data.get('data')
            for question_data in questions_data:
                question_serializer = QuestionSerializer(data={
                    'question': question_data.get('question'),
                    'quiz': quiz.id,
                    'hint': question_data.get('hint'),
                    'description': question_data.get('description')
                })
                if question_serializer.is_valid():
                    question = question_serializer.save()
                    options_data = question_data.get('options')
                    for option_data in options_data:
                        option_serializer = OptionSerializer(data={
                            'option': option_data.get('option'),
                            'question': question.id,
                            'is_correct': option_data.get('is_correct')
                        })
                        if option_serializer.is_valid():
                            option_serializer.save()
                        else:
                            return Response(option_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
                else:
                    return Response(question_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

            return Response(quiz_serializer.data, status=status.HTTP_201_CREATED)

class QuestionUpdateAPIView(APIView):
   
    permission_classes = [IsTeacher]

    def put(self, request, question_id):
        try:
            question = Question.objects.get(id=question_id)
        except Question.DoesNotExist:
            return Response({'error': 'Question not found'}, status=status.HTTP_404_NOT_FOUND)

        # Update the question, hint, and description
        question_data = {
            'question': request.data.get('question'),
            'hint': request.data.get('hint'),
            'description': request.data.get('description')
        }

        question_serializer = QuestionSerializer(question, data=question_data, partial=True)
        if question_serializer.is_valid():
            question_serializer.save()
        else:
            return Response(question_serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        # Update the options
        options_data = request.data.get('options')
        for option_data in options_data:
            option_id = option_data.get('id')
            try:
                option = Option.objects.get(id=option_id)
                option_serializer = OptionSerializer(option, data=option_data, partial=True)
                if option_serializer.is_valid():
                    option_serializer.save()
                else:
                    return Response(option_serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            except Option.DoesNotExist:
                return Response({'error': f'Option with id {option_id} not found for the given question'}, status=status.HTTP_404_NOT_FOUND)

        # Return the updated question and options
        options = Option.objects.filter(question=question.id)
        response_data = {
            'question_id': question.id,
            'question': question.question,
            'hint': question.hint,
            'description': question.description,
            'options': OptionSerializer(options, many=True).data
        }

        return Response(response_data, status=status.HTTP_200_OK)
    

class ScoreAPIView(APIView):

    permission_classes = [IsAuthenticated]

    def post(self, request):
        user = request.user
        quiz_id = request.data.get('quiz_id')
        data = request.data.get('data')

        # Check if the quiz exists
        try:
            quiz = Quiz.objects.get(id=quiz_id)
        except Quiz.DoesNotExist:
            return Response({'error': 'Quiz not found'}, status=status.HTTP_404_NOT_FOUND)

        # Calculate the score
        score_data = 0
        for item in data:
            question_id = item.get('question_id')
            option_id = item.get('option_id')

            try:
                option = Option.objects.get(id=option_id, question=question_id)
                if option.is_correct:
                    score_data += 1
            except Option.DoesNotExist:
                pass

        # Create a QuestionSet object
        question_set = QuestionSet.objects.create(
            user=user,
            quiz=quiz,
            played_date=timezone.now(),
            score=score_data
        )

        # Create QuestionSetDetails objects
        for item in data:
            question_id = item.get('question_id')
            option_id = item.get('option_id')
            QuestionSetDetails.objects.create(
                question_set=question_set,
                question_id=question_id,
                option=option_id
            )

        # Retrieve related objects for the response
        category = quiz.category
        difficulty_level = quiz.difficulty_level

        response_data = {
            'questionset_id': question_set.id,
            'quiz_id': quiz.id,
            'title': quiz.title,
            'category_id': category.id,
            'category': category.category,
            'difficulty_level_id': difficulty_level.id,
            'difficulty_level': difficulty_level.difficulty_level,
            'score': score_data
        }

        return Response(response_data, status=status.HTTP_200_OK)



class QuizHistoryAPIView(APIView):

    permission_classes = [IsAuthenticated]

    def get(self, request):
        user = request.user

        if user.role == "teacher":
            question_sets = QuestionSet.objects.all()
        elif user.role == "student":
            question_sets = QuestionSet.objects.filter(user=user)
        else:
            return Response({'error': 'Unauthorized access'}, status=status.HTTP_403_FORBIDDEN)

        quiz_history = []
        for question_set in question_sets:
            quiz = question_set.quiz
            category = quiz.category
            difficulty_level = quiz.difficulty_level

            data = {
                'questionset_id': question_set.id,
                'quiz_id': quiz.id,
                'title': quiz.title,
                'category_id': category.id,
                'category': category.category,
                'difficulty_level_id': difficulty_level.id,
                'difficulty_level': difficulty_level.difficulty_level,
                'played_date': question_set.played_date.strftime('%Y-%m-%d'),
                'first_name': user.first_name,
                'score': question_set.score
            }
            quiz_history.append(data)

        serializer = QuizHistorySerializer(quiz_history, many=True)
        return Response(serializer.data, status=status.HTTP_200_OK)


class QuestionDetailAPIView(APIView):

    permission_classes = [IsAuthenticated]

    def get(self, request, questionset_id):
        try:
            question_set = QuestionSet.objects.get(id=questionset_id)
        except QuestionSet.DoesNotExist:
            return Response({'error': 'QuestionSet not found'}, status=status.HTTP_404_NOT_FOUND)

        quiz = question_set.quiz
        category = quiz.category
        difficulty_level = quiz.difficulty_level
    
        questions = Question.objects.filter(quiz=quiz)
        print("quiz id ",quiz)
        print(questions)
        data = []
        for question in questions:
            options = Option.objects.filter(question=question)
            print("option", options)
            #all questions may not be answered. Handle exception
            try:
                question_set_detail = QuestionSetDetails.objects.get(question_set=question_set, question=question)
                selected_option_id = question_set_detail.option
            except QuestionSetDetails.DoesNotExist:
                selected_option_id = None

            question_data = {
                'question_id': question.id,
                'question': question.question,
                'hint': question.hint,
                'description': question.description,
                'selected_option_id': selected_option_id,
                'options': OptionSerializer(options, many=True).data
            }
            data.append(question_data)

        response_data = {
            'quiz_id': quiz.id,
            'title': quiz.title,
            'category': category.category,
            'category_id': category.id,
            'difficulty_level': difficulty_level.difficulty_level,
            'difficulty_level_id': difficulty_level.id,
            'score': question_set.score,
            'data': data
        }

        return Response(response_data, status=status.HTTP_200_OK)
    
    def delete(self, request, questionset_id):
        
        try:
            # Assuming questionset_id is the primary key of the question set
            question_set = QuestionSet.objects.get(pk=questionset_id)
        except Question.DoesNotExist:
            return Response({'error': 'Question set not found'}, status=404)

        # Delete the question set
        question_set.delete()

        return Response({'message': 'Question set deleted successfully'}, status=204)
