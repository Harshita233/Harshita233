import string
import random

def generate_password(length=7):
    # Define the characters to use in the password
    characters = string.ascii_letters + string.digits
    
    # Generate the password
    password = ''.join(random.choice(characters) for i in range(length))
    
    return password