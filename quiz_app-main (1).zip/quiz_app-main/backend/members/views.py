from django.contrib.auth import authenticate, login
from django.contrib.auth.models import User
from rest_framework import generics, permissions, status
from rest_framework.response import Response
from rest_framework_simplejwt.tokens import AccessToken
from rest_framework_simplejwt.authentication import JWTAuthentication
from rest_framework.views import APIView
from rest_framework.generics import GenericAPIView

from .models import UserAccount
from .permissions import IsOwnerOrAdmin, IsStudent, IsTeacher
from .serializers import RegisterUserSerializer,  UserAccountSerializer, UserUpdateSerializer
from rest_framework_simplejwt.tokens import RefreshToken
from rest_framework import viewsets
from rest_framework.permissions import IsAdminUser, IsAuthenticated

from django.core.mail import send_mail
from django.conf import settings
from django.template.loader import render_to_string
from django.utils.html import strip_tags
from .utils import generate_password

class RegisterUsersView(APIView):
    serializer_class = RegisterUserSerializer
    # permission_classes = [permissions.AllowAny]

    def post(self, request, format='json'):
        serializer = RegisterUserSerializer(data=request.data)
        if serializer.is_valid():
            new_user = serializer.save()
            if new_user:
                json = serializer.data
                return Response(json, status=status.HTTP_201_CREATED)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class BlacklistTokenUpdateView(APIView):
    permission_classes = [permissions.AllowAny]
    authentication_classes = ()

    def post(self, request):
        try:
            refresh_token = request.data["refresh_token"]
            token = RefreshToken(refresh_token)
            token.blacklist()
            return Response(status=status.HTTP_205_RESET_CONTENT)
        except Exception as e:
            return Response(status=status.HTTP_400_BAD_REQUEST)

# FOR CRUD OPERATION
class UserAccountViewSet(viewsets.ModelViewSet):
    queryset = UserAccount.objects.all()
    serializer_class = UserAccountSerializer

    def get_permissions(self):
        if self.action == 'list' or self.action == 'retrieve':
            permission_classes = [IsAuthenticated]
        elif self.action == 'create':
            permission_classes = [IsAdminUser]
        elif self.action == 'update' or self.action == 'partial_update':
            permission_classes = [IsAuthenticated, IsOwnerOrAdmin | IsTeacher | IsStudent]
        else:
            permission_classes = [IsAdminUser]
        return [permission() for permission in permission_classes]


# FOR GET AND UPDATE WITH JWT
class UserDetailView(GenericAPIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]
    serializer_class = UserAccountSerializer

    def get(self, request):
        user = request.user
        serializer = UserAccountSerializer(user)
        return Response(serializer.data)

    def put(self, request):
        user = request.user
        serializer = UserUpdateSerializer(user, data=request.data, partial=True)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

class NotifyView(APIView):
    def post(self, request):
        data = request.data
        email_address = data.get('email')
        password = generate_password()

        try:
            user = UserAccount.objects.get(email=email_address)
        except UserAccount.DoesNotExist:
            return Response({'error': 'User email not found'}, status=404)
        
        html_message = render_to_string('password_reset_email.html', {'password': password})
        subject = 'Password Reset'
        plain_message = strip_tags(html_message)  # Strip HTML tags for plain text email
        data = {'password': password}

        serializer = UserUpdateSerializer(user, data=data, partial=True)
        
        if serializer.is_valid():
            serializer.save()
            print(password)
            send_mail(subject, plain_message, 'settings.EMAIL_HOST_USER', [email_address], html_message=html_message)
            return Response("Email sent successfully", status=status.HTTP_200_OK)
        
        return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)

        
class InquiryView(APIView):
    def post(self, request):
        data = request.data
        
        user = settings.EMAIL_HOST_USER;
        admin = settings.EMAIL_ADMIN_USER;
      
        user_email = data.get('email')
        name = data.get('name')
        message = data.get('message')

        admin_html_message = render_to_string('inquiry_detail_email.html', {'name': name, 'email':user_email,'message':message})
        admin_subject = 'Inquiry Received'
        admin_plain_message = strip_tags(admin_html_message)  # Strip HTML tags for plain text email
        
        user_html_message = render_to_string('inquiry_response_email.html')
        user_subject = 'Inquiry Received'
        user_plain_message = strip_tags(user_html_message)  # Strip HTML tags for plain text email
        
        send_mail(admin_subject, admin_plain_message, user, [admin], html_message=admin_html_message)
        print("email sent to admin")
        send_mail(user_subject, user_plain_message, user, [user_email], html_message=user_html_message)
        print("email sent to user")
        return Response("Email sent successfully", status=status.HTTP_200_OK)
