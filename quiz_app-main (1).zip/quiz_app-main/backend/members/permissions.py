from rest_framework.permissions import BasePermission
from rest_framework_simplejwt.authentication import JWTAuthentication
from .models import UserAccount

class IsTeacher(BasePermission):
    def has_permission(self, request, view):
        is_authenticated = JWTAuthentication().authenticate(request)
        return is_authenticated and request.user.role == UserAccount.ROLE_CHOICES[1][0]

class IsStudent(BasePermission):
    def has_permission(self, request, view):
        is_authenticated = JWTAuthentication().authenticate(request)
        return is_authenticated and request.user.role == UserAccount.ROLE_CHOICES[2][0]

class IsOwnerOrAdmin(BasePermission):
    def has_object_permission(self, request, view, obj):
        is_authenticated = JWTAuthentication().authenticate(request)
        return is_authenticated and request.user.role == UserAccount.ROLE_CHOICES[0][0]
