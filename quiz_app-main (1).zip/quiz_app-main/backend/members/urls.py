from django.urls import path,include
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)
from rest_framework.routers import DefaultRouter

from .views import BlacklistTokenUpdateView, InquiryView, NotifyView, RegisterUsersView, UserAccountViewSet, UserDetailView



router = DefaultRouter()
router.register('users', UserAccountViewSet, basename='users')

urlpatterns = [
    path('token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
    
    path('register/', RegisterUsersView.as_view(), name="register_user"),
    path('logout/', BlacklistTokenUpdateView.as_view(),name='blacklist'),
    path('', include(router.urls)),

    # USER GET AND PUT 
    path('user-detail/', UserDetailView.as_view(), name='user-detail'),
    
    #send email
    path('notify/', NotifyView.as_view(), name='notify'),
    path('inquiry/', InquiryView.as_view(), name='inquiry'),
]

